Paso 1. Crear la base de datos mysql, BORRARLA SI YA EXISTE PORQUE SE REALIZARON CAMBIOS; crearla con el script .sql incluido, la version usada para esta practica fue la 8.0 

Paso 2 Abrir el proyecto en el editor Visual Studio Code 

Paso 3. Generar el entorno virtual (Si ya existe saltrar al siguiente)

Paso 4. Habilitar el entorno virtual 

Paso 5. Instalar todos los PIP que se encuentran en el requieements

Paso 6. Cambiar la contraseña de la base de datos en el archivo conexion.py

Paso 7. Realizar la Ejecucion de el programa main.py 

paso 8. Al iniciar sesion usar al usuario administrador de prueba 
usuario: 999 contraseña: 123456
la clave de gerente de momento es: 1234